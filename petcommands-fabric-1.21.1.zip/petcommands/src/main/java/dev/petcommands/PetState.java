package dev.petcommands;

import java.util.ArrayList;
import net.minecraft.entity.Entity;
import net.minecraft.entity.passive.CatEntity;
import net.minecraft.entity.passive.TameableEntity;
import net.minecraft.entity.passive.WolfEntity;
import net.minecraft.util.math.BlockPos;

/**
 * Состояние питомца хранится в командных тегах сущности (/tag), поэтому оно
 * сохраняется в мире без дополнительных API.
 */
public final class PetState {
    public enum Mode { FOLLOW, PATROL, PASSIVE }

    private static final String TAG_PATROL = "petcmd_patrol";
    private static final String TAG_PASSIVE = "petcmd_passive";
    private static final String TAG_DUMB = "petcmd_nosmart";
    private static final String TAG_ANCHOR = "petcmd_anchor_";

    private PetState() {}

    public static boolean isSupported(Entity e) {
        return e instanceof WolfEntity || e instanceof CatEntity;
    }

    public static Mode getMode(TameableEntity pet) {
        if (!(pet instanceof WolfEntity)) return Mode.FOLLOW;
        if (pet.getCommandTags().contains(TAG_PATROL)) return Mode.PATROL;
        if (pet.getCommandTags().contains(TAG_PASSIVE)) return Mode.PASSIVE;
        return Mode.FOLLOW;
    }

    public static void apply(TameableEntity pet, Mode mode) {
        pet.removeCommandTag(TAG_PATROL);
        pet.removeCommandTag(TAG_PASSIVE);
        for (String tag : new ArrayList<>(pet.getCommandTags())) {
            if (tag.startsWith(TAG_ANCHOR)) pet.removeCommandTag(tag);
        }
        if (mode == Mode.PATROL) {
            pet.addCommandTag(TAG_PATROL);
            BlockPos p = pet.getBlockPos();
            pet.addCommandTag(TAG_ANCHOR + p.getX() + "_" + p.getY() + "_" + p.getZ());
        } else if (mode == Mode.PASSIVE) {
            pet.addCommandTag(TAG_PASSIVE);
        }
        if (mode != Mode.FOLLOW && pet.isSitting()) {
            pet.setSitting(false);
            pet.setInSittingPose(false);
        }
        pet.getNavigation().stop();
        if (mode == Mode.PASSIVE) {
            pet.setTarget(null);
        }
    }

    public static BlockPos getAnchor(TameableEntity pet) {
        for (String tag : pet.getCommandTags()) {
            if (tag.startsWith(TAG_ANCHOR)) {
                String[] p = tag.substring(TAG_ANCHOR.length()).split("_");
                try {
                    return new BlockPos(Integer.parseInt(p[0]), Integer.parseInt(p[1]), Integer.parseInt(p[2]));
                } catch (RuntimeException ignored) {
                    return null;
                }
            }
        }
        return null;
    }

    /** Умный режим включён по умолчанию. */
    public static boolean isSmart(TameableEntity pet) {
        return !pet.getCommandTags().contains(TAG_DUMB);
    }

    public static void setSmart(TameableEntity pet, boolean smart) {
        if (smart) pet.removeCommandTag(TAG_DUMB);
        else pet.addCommandTag(TAG_DUMB);
    }

    public static String describe(Mode mode) {
        return switch (mode) {
            case FOLLOW -> "следует за тобой";
            case PATROL -> "патрулирует эту местность";
            case PASSIVE -> "не атакует";
        };
    }
}
