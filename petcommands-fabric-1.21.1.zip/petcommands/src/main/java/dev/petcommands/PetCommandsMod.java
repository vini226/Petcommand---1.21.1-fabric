package dev.petcommands;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.boss.WitherEntity;
import net.minecraft.entity.mob.CreeperEntity;
import net.minecraft.entity.mob.EndermanEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.WardenEntity;
import net.minecraft.entity.mob.ZombifiedPiglinEntity;
import net.minecraft.entity.passive.TameableEntity;
import net.minecraft.entity.passive.WolfEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.registry.tag.DamageTypeTags;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import static net.minecraft.server.command.CommandManager.literal;

public class PetCommandsMod implements ModInitializer {
    /** Если умный питомец дальше этого расстояния от хозяина, он телепортируется к нему. */
    public static final double TELEPORT_DISTANCE = 48.0;

    private static final Set<TameableEntity> PETS = ConcurrentHashMap.newKeySet();

    @Override
    public void onInitialize() {
        // Подключаем новое поведение к каждому волку / кошке при загрузке.
        ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
            if (entity instanceof WolfEntity wolf) {
                wolf.goalSelector.add(3, new PatrolGoal(wolf));
                wolf.targetSelector.add(0, new PassiveGoal(wolf));
                wolf.targetSelector.add(4, new ActiveTargetGoal<>(wolf, HostileEntity.class, 5, true, false,
                    target -> isPatrolTarget(wolf, target)));
            }
            if (entity instanceof TameableEntity pet && PetState.isSupported(pet)) {
                PETS.add(pet);
            }
        });
        ServerEntityEvents.ENTITY_UNLOAD.register((entity, world) -> PETS.remove(entity));

        // Умные питомцы не получают урон от падения.
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            if (entity instanceof TameableEntity pet
                && PetState.isSupported(pet)
                && pet.isTamed()
                && PetState.isSmart(pet)
                && source.isIn(DamageTypeTags.IS_FALL)) {
                return false;
            }
            return true;
        });

        // Раз в секунду: слишком далёкие умные питомцы телепортируются к хозяину,
        // пока их чанк ещё не выгружен.
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.getTicks() % 20 != 0) return;
            for (TameableEntity pet : PETS) {
                smartTick(pet);
            }
        });

        // Жест: Shift + ПКМ пустой рукой по своему питомцу.
        UseEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world.isClient || hand != Hand.MAIN_HAND) return ActionResult.PASS;
            if (!player.isSneaking() || !player.getMainHandStack().isEmpty()) return ActionResult.PASS;
            if (!(entity instanceof TameableEntity pet) || !PetState.isSupported(pet)
                || !pet.isTamed() || !pet.isOwner(player)) {
                return ActionResult.PASS;
            }
            cycle(player, pet);
            return ActionResult.SUCCESS;
        });

        // Команды: /pet ... и /pet all ...
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
            dispatcher.register(actions(literal("pet"), false).then(actions(literal("all"), true))));
    }

    private static void smartTick(TameableEntity pet) {
        if (pet.isRemoved() || !pet.isTamed() || !PetState.isSmart(pet)) return;
        if (pet.isSitting() || pet.isLeashed() || pet.hasVehicle()) return;
        if (PetState.getMode(pet) == PetState.Mode.PATROL) return;
        LivingEntity owner = pet.getOwner();
        if (owner == null || owner.isSpectator()) return;
        if (pet.squaredDistanceTo(owner) > TELEPORT_DISTANCE * TELEPORT_DISTANCE) {
            pet.tryTeleportToOwner();
        }
    }

    private static boolean isPatrolTarget(WolfEntity wolf, LivingEntity target) {
        if (!wolf.isTamed() || wolf.isSitting() || PetState.getMode(wolf) != PetState.Mode.PATROL) return false;
        if (target instanceof CreeperEntity || target instanceof EndermanEntity || target instanceof WardenEntity
            || target instanceof WitherEntity || target instanceof ZombifiedPiglinEntity) {
            return false;
        }
        BlockPos anchor = PetState.getAnchor(wolf);
        if (anchor == null) return false;
        int r = PatrolGoal.RADIUS + 6;
        return target.getBlockPos().getSquaredDistance(anchor) <= r * r;
    }

    private static void cycle(PlayerEntity player, TameableEntity pet) {
        if (pet instanceof WolfEntity) {
            PetState.Mode next = switch (PetState.getMode(pet)) {
                case FOLLOW -> PetState.Mode.PATROL;
                case PATROL -> PetState.Mode.PASSIVE;
                case PASSIVE -> PetState.Mode.FOLLOW;
            };
            PetState.apply(pet, next);
            player.sendMessage(Text.literal("Волк: " + PetState.describe(next)), true);
        } else {
            boolean smart = !PetState.isSmart(pet);
            PetState.setSmart(pet, smart);
            player.sendMessage(Text.literal("Кошка: умный режим " + (smart ? "включён" : "выключен")), true);
        }
    }

    private static LiteralArgumentBuilder<ServerCommandSource> actions(LiteralArgumentBuilder<ServerCommandSource> root, boolean all) {
        return root
            .then(literal("follow").executes(c -> setMode(c.getSource(), PetState.Mode.FOLLOW, all)))
            .then(literal("patrol").executes(c -> setMode(c.getSource(), PetState.Mode.PATROL, all)))
            .then(literal("passive").executes(c -> setMode(c.getSource(), PetState.Mode.PASSIVE, all)))
            .then(literal("smart")
                .then(literal("on").executes(c -> setSmart(c.getSource(), true, all)))
                .then(literal("off").executes(c -> setSmart(c.getSource(), false, all))));
    }

    private static int setMode(ServerCommandSource src, PetState.Mode mode, boolean all) throws CommandSyntaxException {
        ServerPlayerEntity player = src.getPlayerOrThrow();
        int count = 0;
        for (TameableEntity pet : targets(player, all)) {
            if (!(pet instanceof WolfEntity)) continue;
            PetState.apply(pet, mode);
            count++;
        }
        if (count == 0) {
            src.sendError(Text.literal("Нужен твой прирученный волк: посмотри на него (до 8 блоков) или используй /pet all ..."));
            return 0;
        }
        final int n = count;
        src.sendFeedback(() -> Text.literal("Волков: " + n + ". Режим: " + PetState.describe(mode)), false);
        return n;
    }

    private static int setSmart(ServerCommandSource src, boolean smart, boolean all) throws CommandSyntaxException {
        ServerPlayerEntity player = src.getPlayerOrThrow();
        int count = 0;
        for (TameableEntity pet : targets(player, all)) {
            PetState.setSmart(pet, smart);
            count++;
        }
        if (count == 0) {
            src.sendError(Text.literal("Нужен твой прирученный волк или кошка: посмотри на него (до 8 блоков) или используй /pet all ..."));
            return 0;
        }
        final int n = count;
        src.sendFeedback(() -> Text.literal("Питомцев: " + n + ". Умный режим " + (smart ? "включён" : "выключен")), false);
        return n;
    }

    /** Питомец, на которого смотрит игрок, или все свои питомцы в радиусе 32 блоков. */
    private static List<TameableEntity> targets(ServerPlayerEntity player, boolean all) {
        if (all) {
            Box box = player.getBoundingBox().expand(32.0);
            return player.getWorld().getEntitiesByClass(TameableEntity.class, box,
                e -> PetState.isSupported(e) && e.isTamed() && e.isOwner(player));
        }
        Vec3d eye = player.getEyePos();
        Vec3d look = player.getRotationVec(1.0F);
        Vec3d end = eye.add(look.multiply(8.0));
        Box box = player.getBoundingBox().stretch(look.multiply(8.0)).expand(1.0);
        EntityHitResult hit = ProjectileUtil.raycast(player, eye, end, box,
            e -> !e.isSpectator() && e.canHit() && e instanceof TameableEntity t
                && PetState.isSupported(t) && t.isTamed() && t.isOwner(player),
            64.0);
        if (hit != null && hit.getEntity() instanceof TameableEntity pet) {
            return List.of(pet);
        }
        return List.of();
    }
}
