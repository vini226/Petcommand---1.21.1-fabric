package dev.petcommands;

import java.util.EnumSet;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.passive.WolfEntity;

/**
 * Работает в targetSelector с приоритетом 0 и занимает управление TARGET,
 * поэтому остальные цели (месть, защита хозяина и т.д.) не могут запуститься.
 */
public class PassiveGoal extends Goal {
    private final WolfEntity wolf;

    public PassiveGoal(WolfEntity wolf) {
        this.wolf = wolf;
        this.setControls(EnumSet.of(Goal.Control.TARGET));
    }

    private boolean active() {
        return wolf.isTamed() && PetState.getMode(wolf) == PetState.Mode.PASSIVE;
    }

    @Override
    public boolean canStart() {
        return active();
    }

    @Override
    public boolean shouldContinue() {
        return active();
    }

    @Override
    public boolean shouldRunEveryTick() {
        return true;
    }

    @Override
    public void start() {
        wolf.setTarget(null);
        wolf.setAttacker(null);
    }

    @Override
    public void tick() {
        if (wolf.getTarget() != null) {
            wolf.setTarget(null);
            wolf.setAttacker(null);
        }
    }
}
