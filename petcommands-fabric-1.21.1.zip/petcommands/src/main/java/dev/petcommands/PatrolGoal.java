package dev.petcommands;

import java.util.EnumSet;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.passive.WolfEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/** Волк бродит по случайным точкам вокруг точки, где ему дали команду. */
public class PatrolGoal extends Goal {
    public static final int RADIUS = 10;

    private final WolfEntity wolf;
    private int wait;

    public PatrolGoal(WolfEntity wolf) {
        this.wolf = wolf;
        this.setControls(EnumSet.of(Goal.Control.MOVE));
    }

    private boolean active() {
        return wolf.isTamed()
            && !wolf.isSitting()
            && !wolf.isLeashed()
            && wolf.getTarget() == null
            && PetState.getMode(wolf) == PetState.Mode.PATROL
            && PetState.getAnchor(wolf) != null;
    }

    @Override
    public boolean canStart() {
        return active();
    }

    @Override
    public boolean shouldContinue() {
        return active();
    }

    @Override
    public void start() {
        wait = 0;
    }

    @Override
    public void stop() {
        wolf.getNavigation().stop();
    }

    @Override
    public void tick() {
        if (wait > 0) {
            wait--;
            return;
        }
        if (!wolf.getNavigation().isIdle()) return;

        BlockPos anchor = PetState.getAnchor(wolf);
        if (anchor == null) return;
        var rnd = wolf.getRandom();

        // Если волка унесло далеко, он возвращается к центру патруля.
        if (wolf.getBlockPos().getSquaredDistance(anchor) > (RADIUS + 4) * (RADIUS + 4)) {
            wolf.getNavigation().startMovingTo(anchor.getX() + 0.5, anchor.getY(), anchor.getZ() + 0.5, 1.1);
            wait = 20;
            return;
        }

        World world = wolf.getWorld();
        BlockPos target = null;
        for (int i = 0; i < 8 && target == null; i++) {
            int x = anchor.getX() + rnd.nextInt(RADIUS * 2 + 1) - RADIUS;
            int z = anchor.getZ() + rnd.nextInt(RADIUS * 2 + 1) - RADIUS;
            target = findStand(world, x, anchor.getY(), z);
        }
        if (target != null) {
            wolf.getNavigation().startMovingTo(target.getX() + 0.5, target.getY(), target.getZ() + 0.5, 1.0);
        }
        wait = 40 + rnd.nextInt(80);
    }

    private static BlockPos findStand(World world, int x, int y, int z) {
        if (!world.getChunkManager().isChunkLoaded(x >> 4, z >> 4)) return null;
        for (int dy = 3; dy >= -5; dy--) {
            BlockPos p = new BlockPos(x, y + dy, z);
            if (free(world, p) && free(world, p.up()) && !free(world, p.down())
                && world.getFluidState(p).isEmpty() && world.getFluidState(p.down()).isEmpty()) {
                return p;
            }
        }
        return null;
    }

    private static boolean free(World world, BlockPos pos) {
        return world.getBlockState(pos).getCollisionShape(world, pos).isEmpty();
    }
}
